from Control3DBase.Control3DProgram import GraphicsProgram3D

if __name__ == '__main__':
    prog = GraphicsProgram3D()
    prog.start()