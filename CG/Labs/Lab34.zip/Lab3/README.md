## Lab 3/4

This folder contains work done for Labs 3 and 4, since they are related

### Running

```
pip install pipenv # if pipenv isn't installed
pipenv install
pipenv run main.py
```